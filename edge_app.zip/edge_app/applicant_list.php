<?php
	include "header.php";
	include "dbconnect.php";

	$sql = "SELECT * FROM applicant";
	$result = $conn->query($sql);
?>

<style>
			span a{
					text-decoration: none;
					text-align: center;
					background-color: #04AA6D;
					color: white;
					padding: 8px 12px;
					border-radius: 5px;
}
.align_button{
	margin-left: 45%;
}
		</style>
<h1 align="center">Applicant List</h1>
<table>
	<tr>
		<th>SL</th>
		<th>Name</th>
		<th>Email</th>
		<th>Phone</th>
		<th>Gender</th>
		<th>Date of Birth</th>
		<th>Selected Course</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	
		<?php 
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc())
			{ 
				$id=$row["id"];
				echo "<tr>"; 
			echo "<td>".$row["id"] ."</td>";	
			echo "<td>".$row["name"] ."</td>";	
			echo "<td>". $row["email"]."</td>";	
			echo "<td>". $row["phone"]."</td>";	
			echo "<td>". $row["gender"]."</td>";	
			echo "<td>". $row["dob"]."</td>";	
			echo "<td>". $row["course_id"]."</td>";	
			echo "<td>"."<a href='update.php?editid=$id'>Edit</a>"."</td>";
					echo "<td>"."<a href='delete.php?delid=$id'>Delete</a>"."</td>";
			}
		}
		else echo "0 results";
		?>
	
			
</table>
	<div>
		<span class="align_button">
		<a href="application.php">Add New Applicnt</a>
		</span>
		</div>
		
<?php
	include "footer.php";
?>		


