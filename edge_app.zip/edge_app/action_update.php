<?php
include "header.php";

$id = $_POST['id'];
$name=$_POST["name"];
		$eml=$_POST["email"];
		$phon=$_POST["phone"];
		$gen=$_POST["gender"];
		$dob=$_POST["dob"];
		$course_id=$_POST["course"];


$server_name="localhost";
$user_name="root";
$password="";
$database_name="edge_app";

$conn = new mysqli($server_name, $user_name, $password, $database_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE applicant SET name='$name', email='$eml',phone='$phon', gender='$gen', dob='$dob', course_id='$course_id' WHERE id=$id";
$result=$conn->query($sql);

if ($result) {
    header("Location:applicant_list.php");
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();


exit();
?>
<?php
	include "footer.php";
?>		

