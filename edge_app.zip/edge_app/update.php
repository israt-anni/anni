
<?php
include "header.php";
		
$server_name = "localhost";
$user_name = "root";
$password = "";
$database_name = "edge_app";

$conn = new mysqli($server_name, $user_name, $password, $database_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['editid'];
$sql = "SELECT * FROM applicant WHERE id=$id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$conn->close();
?>

<html>
    <head>
        <title>Update Student</title>
        <style>
            div { background-color: #f2f2f2; width: 30%; margin: auto; border-radius: 7px; padding: 16px; }
            input[type=text], input[type=email], input[type=date], input[type=number] {
                width: 100%; padding: 14px 8px; margin: 5px; border-radius: 5px;
            }
            input[type=submit] {
                width: 100%; padding: 14px 8px; margin: 5px; border-radius: 5px;
                background-color: #2ecc71; color: #ffffff; font-size: 20px;
            }
            input[type=submit]:hover {
                background-color: #27ae60; color: #ffffff;
            }
        </style>
    </head>
    <body>
        <div>
            <h1>Update Student</h1>
            <form action="action_update.php" method="POST">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <label>Name</label>
                <input type="text" name="name" value="<?php echo $row['name']; ?>">
                <label>Email</label>
                <input type="email" name="email" value="<?php echo $row['email']; ?>">
				<label>Phone</label>
                <input type="text" name="phone" value="<?php echo $row['phone']; ?>">
               <label>Gender</label>
			<input type="radio" name="gender" value="<?php echo $row['gender']; ?>" > Male
			<input type="radio" name="gender" value="<?php echo $row['gender']; ?>"> Female <br> <br>
			<label>Date of Birth</label>
			<input type="date" name="dob" value="<?php echo $row['dob']; ?>">
			<label>Choose Course</label>
			<select name="course" >
			<?php
				while($row=$result->fetch_assoc()){
		echo '<option value="'.$row["id"] .'">'.$row["title"] .'</option>';
				}
			?>
			</select>
			<input type="submit" value="Submit">
			</form>
			</div>
    </body>
	<?php
	include "footer.php";
?>		

</html>
